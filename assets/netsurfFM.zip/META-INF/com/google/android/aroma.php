<?php // Netsurf Browser Installer
echo "Netsurf Browser Installer";